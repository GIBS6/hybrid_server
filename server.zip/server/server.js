const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { spawn } = require('child_process');
const winston = require('winston');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const circuitBreaker = require('circuit-breaker-js');
const compression = require('compression');
const cors = require('cors');
const cacheManager = require('cache-manager');
const Redis = require('ioredis');
const Prometheus = require('prom-client');
const nodemailer = require('nodemailer');
const dgram = require('dgram');
const dns = require('dns');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'server.log' }),
    new winston.transports.Console(),
  ],
});

const app = express();
const port = 3000;

// Enable helmet for security
app.use(helmet());

// Enable CORS
app.use(cors());

// Enable compression
app.use(compression());

// Set up cache
const cache = cacheManager.caching({
  store: 'redis',
  host: 'localhost',
  port: 6379,
  ttl: 60 * 1000, // 1 minute
});

// Set up Redis
const redis = new Redis({
  host: 'localhost',
  port: 6379,
});

// Set up Prometheus
Prometheus.collectDefaultMetrics({
  timeout: 10000,
});

// Enable rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  skip: (req) => req.url === '/healthcheck', // skip rate limiting for health check endpoint
});
app.use(limiter);

// Enable slow down
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 50, // allow 50 requests per 15 minutes, then...
  delayMs: 500, // begin adding 500ms of delay per request above 100:
});
app.use(speedLimiter);

// Set up circuit breaker
const breaker = circuitBreaker({
  timeout: 3000, // 3 seconds
  threshold: 0.5, // 50% failure rate
  window: 60000, // 1 minute
});

// Set up proxy middleware
const djangoProxy = createProxyMiddleware({
  target: 'http://localhost:8000', // Django server URL
  changeOrigin: true,
  onError: (err, req, res) => {
    logger.error('Proxy error:', err);
    res.status(500).send('Proxy error');
  },
});

// Log requests
app.use((req, res, next) => {
  logger.info(`Request: ${req.method} ${req.url}`);
  next();
});

// Use circuit breaker and proxy middleware
app.use('/django', breaker(djangoProxy));

// Handle DNS requests
const dnsServer = dgram.createSocket('udp4');
dnsServer.bind(53, 'localhost', () => {
  logger.info('DNS server started on port 53');
});

function resolveDomain(domain) {
  return new Promise((resolve, reject) => {
    dns.resolve(domain, 'A', (err, addresses) => {
      if (err) {
        reject(err);
      } else {
        resolve(addresses.join(','));
      }
    });
  });
}

dnsServer.on('message', async (message, remoteInfo) => {
  const domain = message.toString();
  try {
    const ipAddresses = await resolveDomain(domain);
    const response = Buffer.from(ipAddresses);
    dnsServer.send(response, 0, response.length, remoteInfo.port, remoteInfo.address);
  } catch (err) {
    logger.error(`Error resolving domain: ${err}`);
  }
});

// Set up alerting system
const transporter = nodemailer.createTransport({
  host: 'smtp.example.com',
  port: 587,
  secure: false, // or 'STARTTLS'
  auth: {
    user: 'username',
    pass: 'password',
  },
});

// Send alert when server error occurs
app.use((err, req, res, next) => {
  logger.error('Server error:', err);
  const mailOptions = {
    from: 'server@example.com',
    to: 'admin@example.com',
    subject: 'Server Error',
    text: `Server error: ${err.message}`,
  };
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      logger.error('Error sending alert:', error);
    } else {
      logger.info('Alert sent:', info.response);
    }
  });
  res.status(500).send('Server error');
});

// Health check
app.get('/healthcheck', (req, res) => {
  res.status(200).send('Server is healthy');
});

// Prometheus metrics endpoint
const prometheusApp = express();
const prometheusPort = 9090;
prometheusApp.get('/metrics', (req, res) => {
  res.set("Content-Type", Prometheus.register.contentType);
  res.end(Prometheus.register.metrics());
});
prometheusApp.listen(prometheusPort, () => {
  logger.info(`Prometheus server started on port ${prometheusPort}`);
});

// 404 handling
app.use((req, res, next) => {
  res.status(404).send('Not found');
});

// Handle unhandled exceptions
process.on('uncaughtException', (err) => {
  logger.error('Unhandled exception:', err);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  logger.error('Unhandled promise rejection:', err);
  process.exit(1);
});

// Start the server
app.listen(port, () => {
  logger.info(`Server started on port ${port}`);
  logger.info('DNS server started on port 53');
});


