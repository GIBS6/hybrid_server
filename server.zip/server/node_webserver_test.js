const request = require('supertest');
const app = require('./server');

describe('Web Server', () => {
  it('should return 200 OK for a valid request', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
  });

  it('should return 404 Not Found for an invalid request', async () => {
    const response = await request(app).get('/invalid');
    expect(response.status).toBe(404);
  });

  it('should rate limit requests', async () => {
    for (let i = 0; i < 100; i++) {
      await request(app).get('/');
    }
    const response = await request(app).get('/');
    expect(response.status).toBe(429);
  });

  it('should handle circuit breaking', async () => {
    // Simulate a failing service
    jest.spyOn(app, 'handleRequest').mockImplementationOnce(() => {
      throw new Error('Service error');
    });
    const response = await request(app).get('/');
    expect(response.status).toBe(500);
  });
});
