import pytest
import dns.resolver

def test_dns_server():
    # Start the DNS server
    server = AdvancedDNSServer()
    server.start_dns_server()

    # Send a DNS query
    resolver = dns.resolver.Resolver()
    resolver.nameservers = ['localhost']
    response = resolver.resolve('example.com', 'A')

    # Verify the response
    assert response is not None
